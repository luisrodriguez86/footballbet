-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-08-2015 a las 21:55:51
-- Versión del servidor: 5.5.32
-- Versión de PHP: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `football`
--
CREATE DATABASE IF NOT EXISTS `football` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `football`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bet`
--

CREATE TABLE IF NOT EXISTS `bet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_id` int(11) DEFAULT NULL,
  `usergrupo_id` int(11) DEFAULT NULL,
  `localwin` tinyint(1) NOT NULL,
  `awaywin` tinyint(1) NOT NULL,
  `draft` tinyint(1) NOT NULL,
  `points` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C3BDAA7BE48FD905` (`game_id`),
  KEY `IDX_C3BDAA7BB0C6CF74` (`usergrupo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `games`
--

CREATE TABLE IF NOT EXISTS `games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `local_id` int(11) DEFAULT NULL,
  `away_id` int(11) DEFAULT NULL,
  `season_id` int(11) DEFAULT NULL,
  `local_goals` int(11) NOT NULL,
  `away_goals` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `updated` tinyint(1) NOT NULL,
  `league_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3EE204355D5A2101` (`local_id`),
  KEY `IDX_3EE204358DEF089F` (`away_id`),
  KEY `IDX_3EE204354EC001D1` (`season_id`),
  KEY `IDX_FF232B3158AFC4DE` (`league_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=127 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F06D397057698A6A` (`role`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcado de datos para la tabla `groups`
--

INSERT INTO `groups` (`id`, `name`, `role`, `description`) VALUES
(1, 'ROLE_SUPER_ADMIN', 'ROLE_SUPER_ADMIN', 'ROLE_SUPER_ADMIN'),
(2, 'ROLE_USER', 'ROLE_USER', 'ROLE_USER'),
(3, 'ROLE_GROUP_ADMIN', 'ROLE_GROUP_ADMIN', 'ROLE_GROUP_ADMIN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupo`
--

CREATE TABLE IF NOT EXISTS `grupo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `league_id` int(11) DEFAULT NULL,
  `group_admin_id` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4DCFB4D76D1BCE6F` (`group_admin_id`),
  KEY `IDX_8C0E9BD358AFC4DE` (`league_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `league`
--

CREATE TABLE IF NOT EXISTS `league` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `logo` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion`
--

CREATE TABLE IF NOT EXISTS `notificacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `grupo_id` int(11) DEFAULT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6AABC214A76ED395` (`user_id`),
  KEY `IDX_6AABC2149C833003` (`grupo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacionforgot`
--

CREATE TABLE IF NOT EXISTS `notificacionforgot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_C4504973A76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicity`
--

CREATE TABLE IF NOT EXISTS `publicity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `expiredate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `publicity`
--

INSERT INTO `publicity` (`id`, `name`, `photo`, `date`, `expiredate`) VALUES
(4, '1', 'a87ff679a2f3e71d9181a67b7542122c.jpeg', '2015-07-09', '2017-01-01'),
(5, '2', 'e4da3b7fbbce2345d7772b0674a318d5.jpeg', '2015-07-09', '2017-01-01'),
(6, '3', '1679091c5a880faf6fb5e6087eb1b2dc.jpeg', '2015-07-09', '2017-01-01'),
(7, '4', '8f14e45fceea167a5a36dedd4bea2543.jpeg', '2015-07-09', '2017-01-01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `season`
--

CREATE TABLE IF NOT EXISTS `season` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `league_id` int(11) DEFAULT NULL,
  `nombre` longtext COLLATE utf8_unicode_ci NOT NULL,
  `logo` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_64D2092158AFC4DE` (`league_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=253 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `photo` longtext COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `register_code` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `points` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `nombre`, `photo`, `salt`, `password`, `email`, `register_code`, `is_active`, `points`) VALUES
(1, 'super_admin', 'fda8afd334a7bf2452f15c56cc28ff6a.jpeg', '0e8028d48e668d5d2361040e3ae59d57', 'gTVGYJY3Xg4jBHkdl+q5fjHBbvY=', 'super_admin@super_admin.com', '0', 1, 2),
(12, 'user@user.com', 'd6c45d3857d4732116a96642b449dd78.jpeg', '202476fb9b0f0b7caef23166376d90db', 'bx7Vtxykx2Aw1XgzZeLoMpW45TQ=', 'user@user.com', '0', 1, 0),
(14, 'groupadmin@groupadmin.com', 'ba3c23d11b19bbdfa8a3e700edcf2a10.jpeg', '5fe04bee38cbe32010177da04be78715', 'Zxm79l+I8cnRmNU8TUXzWLtL68g=', 'groupadmin@groupadmin.com', '0', 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usergrupo`
--

CREATE TABLE IF NOT EXISTS `usergrupo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `grupo_id` int(11) DEFAULT NULL,
  `points` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E89A0AA6A76ED395` (`user_id`),
  KEY `IDX_E89A0AA69C833003` (`grupo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`),
  KEY `IDX_8F02BF9DA76ED395` (`user_id`),
  KEY `IDX_8F02BF9DFE54D947` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `user_group`
--

INSERT INTO `user_group` (`user_id`, `group_id`) VALUES
(1, 1),
(12, 2),
(12, 3),
(14, 3);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bet`
--
ALTER TABLE `bet`
  ADD CONSTRAINT `FK_C3BDAA7BB0C6CF74` FOREIGN KEY (`usergrupo_id`) REFERENCES `usergrupo` (`id`),
  ADD CONSTRAINT `FK_C3BDAA7BE48FD905` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`);

--
-- Filtros para la tabla `games`
--
ALTER TABLE `games`
  ADD CONSTRAINT `FK_3EE204354EC001D1` FOREIGN KEY (`season_id`) REFERENCES `season` (`id`),
  ADD CONSTRAINT `FK_3EE204355D5A2101` FOREIGN KEY (`local_id`) REFERENCES `team` (`id`),
  ADD CONSTRAINT `FK_3EE204358DEF089F` FOREIGN KEY (`away_id`) REFERENCES `team` (`id`),
  ADD CONSTRAINT `FK_FF232B3158AFC4DE` FOREIGN KEY (`league_id`) REFERENCES `league` (`id`);

--
-- Filtros para la tabla `grupo`
--
ALTER TABLE `grupo`
  ADD CONSTRAINT `FK_4DCFB4D76D1BCE6F` FOREIGN KEY (`group_admin_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_8C0E9BD358AFC4DE` FOREIGN KEY (`league_id`) REFERENCES `league` (`id`);

--
-- Filtros para la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD CONSTRAINT `FK_6AABC2149C833003` FOREIGN KEY (`grupo_id`) REFERENCES `grupo` (`id`),
  ADD CONSTRAINT `FK_6AABC214A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Filtros para la tabla `notificacionforgot`
--
ALTER TABLE `notificacionforgot`
  ADD CONSTRAINT `FK_C4504973A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Filtros para la tabla `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `FK_64D2092158AFC4DE` FOREIGN KEY (`league_id`) REFERENCES `league` (`id`);

--
-- Filtros para la tabla `usergrupo`
--
ALTER TABLE `usergrupo`
  ADD CONSTRAINT `FK_E89A0AA69C833003` FOREIGN KEY (`grupo_id`) REFERENCES `grupo` (`id`),
  ADD CONSTRAINT `FK_E89A0AA6A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Filtros para la tabla `user_group`
--
ALTER TABLE `user_group`
  ADD CONSTRAINT `FK_8F02BF9DA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_8F02BF9DFE54D947` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
